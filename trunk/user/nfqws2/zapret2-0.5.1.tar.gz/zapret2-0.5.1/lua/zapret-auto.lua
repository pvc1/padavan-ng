-- arg: reqhost - require hostname, do not work with ip
function automate_host_record(desync)
	local key
	if desync.arg.reqhost then
		key = desync.track and desync.track.hostname
	else
		key = host_or_ip(desync)
	end
	if not key then
		DLOG("automate: host record key unavailable")
		return nil
	end
	DLOG("automate: host record key '"..key.."'")
	if not autostate then
		autostate = {}
	end
	if not autostate[key] then
		autostate[key] = {}
	end
	return autostate[key]
end
function automate_conn_record(desync)
	if not desync.track.lua_state.automate then
		desync.track.lua_state.automate = {}
	end
	return desync.track.lua_state.automate
end

-- counts failure, optionally (if crec is given) prevents dup failure counts in a single connection
-- if 'maxtime' between failures is exceeded then failure count is reset
-- return true if threshold ('fails') is reached
-- hres is host record. host or ip bound table
-- cres is connection record. connection bound table
function automate_failure_counter(hrec, crec, fails, maxtime)
	if crec and crec.failure then
		DLOG("automate: duplicate failure in the same connection. not counted")
	else
		if crec then crec.failure = true end
		local tnow=os.time()
		if not hrec.failure_time_last then
			hrec.failure_time_last = tnow
		end
		if not hrec.failure_counter then
			hrec.failure_counter = 0
		elseif tnow>(hrec.failure_time_last + maxtime) then
			DLOG("automate: failure counter reset because last failure was "..(tnow - hrec.failure_time_last).." seconds ago")
			hrec.failure_counter = 0
		end
		hrec.failure_counter = hrec.failure_counter + 1
		hrec.failure_time_last = tnow
		if b_debug then DLOG("automate: failure counter "..hrec.failure_counter..(fails and ('/'..fails) or '')) end
		if fails and hrec.failure_counter>=fails then
			hrec.failure_counter = nil -- reset counter
			return true
		end
	end
	return false
end

-- location is url compatible with Location: header
-- hostname is original hostname
function is_dpi_redirect(hostname, location)
	local ds = dissect_url(location)
	if ds.domain then
		local sld1 = dissect_nld(hostname,2)
		local sld2 = dissect_nld(ds.domain,2)
		return sld2 and sld1~=sld2
	end
	return false
end

-- standard failure detector
-- works with tcp only
-- detected failures:
--   incoming RST (within `options.seq_rst`)
--   incoming http redirection (if no 'options.no_http_redirect')
--   outgoing retransmissions (`options.retrans` threshold)
-- stops dectecting after seq 'options.maxseq'
function standard_failure_detector(desync, crec, options)
	if not desync.dis.tcp or crec.nocheck then return false end
	local seq = pos_get(desync,'s')
	if options.maxseq and seq>options.maxseq then
		DLOG("standard_failure_detector: s"..seq.." is beyond s"..options.maxseq..". treating connection as successful")
		crec.nocheck = true
		return false
	end

	local trigger = false
	local seq = pos_get(desync,'s')
	if desync.outgoing then
		if #desync.dis.payload>0 and options.retrans and (crec.retrans or 0)<options.retrans then
			if not crec.uppos then crec.uppos=0 end
			if desync.track.tcp.pos_orig<=crec.uppos then
				crec.retrans = crec.retrans and (crec.retrans+1) or 1
				DLOG("standard_failure_detector: retransmission "..crec.retrans.."/"..options.retrans)
				trigger = crec.retrans>=options.retrans
			end
			if desync.track.tcp.pos_orig>crec.uppos then
				crec.uppos=desync.track.tcp.pos_orig
			end
		end
	else
		if options.seq_rst and bitand(desync.dis.tcp.th_flags, TH_RST)~=0 then
			trigger = seq<=options.seq_rst
			if b_debug then
				if trigger then
					DLOG("standard_failure_detector: incoming RST s"..seq.." in range s"..options.seq_rst)
				else
					DLOG("standard_failure_detector: not counting incoming RST s"..seq.." beyond s"..options.seq_rst)
				end
			end
		elseif not options.no_http_redirect and desync.l7payload=="http_reply" and desync.track.hostname then
			local hdis = http_dissect_reply(desync.dis.payload)
			if hdis and (hdis.code==302 or hdis.code==307) and hdis.headers.location and hdis.headers.location then
				trigger = is_dpi_redirect(desync.track.hostname, hdis.headers.location.value)
				if b_debug then
					if trigger then
						DLOG("standard_failure_detector: http redirect "..hdis.code.." to '"..hdis.headers.location.value.."'. looks like DPI redirect.")
					else
						DLOG("standard_failure_detector: http redirect "..hdis.code.." to '"..hdis.headers.location.value.."'. NOT a DPI redirect.")
					end
				end
			end
		end
	end
	return trigger
end

-- circularily change strategy numbers when failure count reaches threshold ('fails')
-- works with tcp only
-- this orchestrator requires redirection of incoming traffic to cache RST and http replies !
-- each orchestrated instance must have strategy=N arg, where N starts from 1 and increment without gaps
-- if 'final' arg is present in an orchestrated instance it stops rotation
-- arg: fails=N - failture count threshold. default is 3
-- arg: retrans=N - retrans count threshold. default is 3
-- arg: seq=<rseq> - if packet is beyond this relative sequence number treat this connection as successful. default is 64K
-- arg: rst=<rseq> - maximum relative sequence number to treat incoming RST as DPI reset. default is 1
-- arg: time=<sec> - if last failure happened earlier than `maxtime` seconds ago - reset failure counter. default is 60.
-- arg: reqhost - pass with no tampering if hostname is unavailable
-- arg: detector - failure detector function name
-- test case: nfqws2 --qnum 200 --debug --lua-init=@zapret-lib.lua --lua-init=@zapret-auto.lua --in-range=-s1 --lua-desync=circular --lua-desync=argdebug:strategy=1 --lua-desync=argdebug:strategy=2
function circular(ctx, desync)
	local function count_strategies(hrec, plan)
		if not hrec.ctstrategy then
			local uniq={}
			local n=0
			for i,instance in pairs(plan) do
				if instance.arg.strategy then
					n = tonumber(instance.arg.strategy)
					if not n or n<1 then
						error("circular: strategy number '"..tostring(instance.arg.strategy).."' is invalid")
					end
					uniq[tonumber(instance.arg.strategy)] = true
					if instance.arg.final then
						hrec.final = n
					end
				end
			end
			n=0
			for i,v in pairs(uniq) do
				n=n+1
			end
			if n~=#uniq then
				error("circular: strategies numbers must start from 1 and increment. gaps are not allowed.")
			end
			hrec.ctstrategy = n
		end
	end

	-- take over orchestration. prevent further instance execution in case of error
	execution_plan_cancel(ctx)

	if not desync.dis.tcp then
		DLOG_ERR("circular: this orchestrator is tcp only. use filters to avoid udp traffic.")
		instance_cutoff(ctx)
		return
	end
	if not desync.track then
		DLOG_ERR("circular: conntrack is missing but required")
		return
	end

	local plan = execution_plan(ctx)
	if #plan==0 then
		DLOG("circular: need some desync instances or useless")
		return
	end

	local hrec = automate_host_record(desync)
	if not hrec then
		DLOG("circular: passing with no tampering")
		return
	end

	count_strategies(hrec, plan)
	if hrec.ctstrategy==0 then
		error("circular: add strategy=N tag argument to each following instance ! N must start from 1 and increment")
	end

	local seq_rst = tonumber(desync.arg.rst) or 1
	local maxseq = tonumber(desync.arg.seq) or 0x10000
	local retrans = tonumber(desync.arg.retrans) or 3
	local fails = tonumber(desync.arg.fails) or 3
	local maxtime = tonumber(desync.arg.time) or 60
	local crec = automate_conn_record(desync)
	local failure_detector
	if desync.arg.detector then
		if type(_G[desync.arg.detector])~="function" then
			error("circular: invalid failure detector function '"..desync.arg.detector.."'")
		end
		failure_detector = _G[desync.arg.detector]
	else
		failure_detector = standard_failure_detector
	end

	if not hrec.nstrategy then
		DLOG("circular: start from strategy 1")
		hrec.nstrategy = 1
	end

	local verdict = VERDICT_PASS
	if hrec.final~=hrec.nstrategy then
		if failure_detector(desync,crec,{retrans=retrans,maxseq=maxseq,seq_rst=seq_rst}) then
			if automate_failure_counter(hrec, crec, fails, maxtime) then
				-- circular strategy change
				hrec.nstrategy = (hrec.nstrategy % hrec.ctstrategy) + 1
				DLOG("circular: rotate strategy to "..hrec.nstrategy)
				if hrec.nstrategy == hrec.final then
					DLOG("circular: final strategy "..hrec.final.." reached. will rotate no more.")
				end
			end
		end
	end

	DLOG("circular: current strategy "..hrec.nstrategy)
	local dcopy = desync_copy(desync)
	for i=1,#plan do
		if plan[i].arg.strategy and tonumber(plan[i].arg.strategy)==hrec.nstrategy then
			verdict = plan_instance_execute(dcopy, verdict, plan[i])
		end
	end

	return verdict
end
