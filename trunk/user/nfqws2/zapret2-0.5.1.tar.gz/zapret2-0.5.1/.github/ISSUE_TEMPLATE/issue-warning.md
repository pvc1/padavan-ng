---
name: bugs
about: do not write lame questions
title: ''
labels: ''
assignees: ''

---

Issues - это место для обращений к разработчику.
Discussions - место для обсуждения вопросов между пользователями.

Все, что выходит за рамки багов и технически грамотных предложений, идей,
вопросы типа "как мне это запустить", "что нажать", "что вписать" - будет безжалостно удаляться.
Идите в дискуссии, не захламляйте issues.

Here is the place for bugs only. All questions, especially user-like questions (non-technical) go to Discussions.
There're also no viruses here. All virus claims and everyting non-technical and non-bugs will be instantly deleted, closed or moved to Discussions.
