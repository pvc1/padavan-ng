This test only checks that test compilation works. This example contains two test executables.

These tests can be used as template for 'real' tests.
